using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour
{
    public NetworkBoard board;

    private float time;
    // Start is called before the first frame update
    void Start()
    {
        board.addBlockToField(1, 1, 1, 1);
        board.addBlockToField(1, 2, 1, 1);
        board.addBlockToField(3, 1, 1, 1);
        board.addBlockToField(4, 1, 1, 1);
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;

        if(time >= 4)
        {
            board.addBlockToField(2, 1, 1, 1);
            time = 0;
        }
    }
}
