using UnityEngine;
using UnityEngine.Tilemaps;

public enum AITetromino
{
    I, J, L, O, S, T, Z
}

[System.Serializable]
public struct AITetrominoData
{
    public Tile tile;
    public Tetromino tetromino;
}