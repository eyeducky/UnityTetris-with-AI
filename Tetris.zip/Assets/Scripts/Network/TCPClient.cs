using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using UnityEngine;
using Unity.VisualScripting;
using UnityEngine.Tilemaps;

public class TCPClient : MonoBehaviour
{
    public NetworkBoard board;

    public bool doAddblock = false;
    public int[] tetrisCoord = new int[4];

    private TcpClient socketConnection;
    private void Start()
    {
        StartCoroutine(Main());
    }

    void OnApplicationQuit()
    {
        StopAllCoroutines();
    }

    IEnumerator Main()
    {
        // ���� �ڵ�s
        char CR = (char)0x0D;
        char LF = (char)0x0A;
        // ���� ����
        StringBuilder sb = new StringBuilder();
        // ������ ����.
        using (Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP))
        {
            // ������ 9090��Ʈ�� �����Ѵ�.
            socket.Connect(IPAddress.Parse("127.0.0.1"), 6974);
            // ������ ���� ������
            ThreadPool.QueueUserWorkItem((_) =>
            {
                // Ŭ���̾�Ʈ ����
                IPEndPoint ip = (IPEndPoint)socket.RemoteEndPoint;
                // �ܼ� ���
                socket.Send(Encoding.Unicode.GetBytes("Welcome server!\r\n>\0"), SocketFlags.None);
                try
                {
                    // ���� ���
                    while (true)
                    {
                        // ������ ���� �޽����� �޴´�.
                        byte[] ret = new byte[2];
                        socket.Receive(ret, 2, SocketFlags.None);
                        // �޽����� unicode�� ��ȯ�ؼ� ���ۿ� �ִ´�.
                        sb.Append(Encoding.Unicode.GetString(ret, 0, 2));
                        // ���� + \n�̸� �ܼ� ����Ѵ�.
                        if (sb.Length >= 2 && sb[sb.Length - 2] == '\r' && sb[sb.Length - 1] == '\n')
                        {
                            // exit�� ������ ���´�.
                            if (sb.Length >= 4 && sb[sb.Length - 4] == 'e' && sb[sb.Length - 3] == 'x' && sb[sb.Length - 2] == 'i' && sb[sb.Length - 1] == 't')
                            {
                                break;
                            }
                            // ������ �޽����� �ֿܼ� ���
                            string msg = sb.ToString();
                            // echo �޽��� ����
                            socket.Send(Encoding.Unicode.GetBytes("echo - " + msg + ">\0"), SocketFlags.None);
                            // split 
                            string[] divMsg = msg.Split('\x020');
                            try
                            {
                                Debug.Log("msg : " + msg);
                                for (int i = 0; i < 4; i++)
                                {
                                    tetrisCoord[i] = int.Parse(divMsg[i]);
                                    Debug.Log(tetrisCoord[0]);
                                }

                                doAddblock = true;
                            }
                            catch
                            {
                                Debug.Log("Type or Amount error");
                            }
                            
                            // �ܼ� ���
                            // ���۸� ����.
                            sb.Clear();
                        }
                    }
                }
                catch
                {
                    // ���� �߻��ϸ� ����
                }
            });
            while (true)
            {
                if (doAddblock == true)
                {
                    doAddblock = false;
                    board.addBlockToField(tetrisCoord[0], tetrisCoord[1], tetrisCoord[2], tetrisCoord[3]);
                }
                yield return null;
            }
        }
    }
}
