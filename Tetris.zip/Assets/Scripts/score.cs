using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Score : MonoBehaviour
{
    private static readonly int HEIGHT = 20;
    private static readonly int WIDTH = 10;
    private static readonly int BLOCK_HEIGHT = 4;
    private static readonly int BLOCK_WIDTH = 4;
    private static readonly int[,] block = new int[BLOCK_HEIGHT, BLOCK_WIDTH];

    
    public TextMeshProUGUI scoreText;
    private int score;

    void Start()
    {
        score = 0;
        UpdateScoreText();
    }
    public int AddBlockToField(int[,] f, int blockY, int blockX)
    {
        int touched = 0;
        for (int i = 0; i < BLOCK_HEIGHT; i++)
        {
            for (int j = 0; j < BLOCK_WIDTH; j++)
            {
                if (block[i, j] == 1 && i + blockY >= 0)
                {
                    f[i + blockY, j + blockX] = 1;
                    if (i + blockY + 1 >= HEIGHT || f[i + blockY + 1, j + blockX] != 0)
                        touched++;
                }
            }
        }
        IncreaseScore(touched * 10);
        return touched * 10;
    }

    public int DeleteLineFromField(int[,] f)
    {
        int cnt = 0;
        int[] deleteLineFromField = new int[HEIGHT];
        for (int i = HEIGHT - 1; i >= 0; i--)
        {
            int j;
            for (j = 0; j < WIDTH; j++)
                if (f[i, j] == 0) break;
            if (j == WIDTH) deleteLineFromField[cnt++] = i;
        }
        for (int k = 0; k < cnt - 1; k++)
            for (int i = deleteLineFromField[k] + k; i >= deleteLineFromField[k + 1] + (k + 1); i--)
                for (int j = 0; j < WIDTH; j++)
                    f[i, j] = (i - (k + 1) >= 0) ? f[i - (k + 1), j] : 0;
        if (cnt > 0)
            for (int i = deleteLineFromField[cnt - 1] + cnt - 1; i >= 0; i--)
                for (int j = 0; j < WIDTH; j++)
                    f[i, j] = (i - cnt >= 0) ? f[i - cnt, j] : 0;
        IncreaseScore(cnt * cnt * 100);
        return cnt * cnt * 100;
    }

    public void IncreaseScore(int increment)
    {
        score += increment;
        UpdateScoreText();
    }

    private void UpdateScoreText()
    {
        scoreText.text = "Score: " + score.ToString();
        Debug.Log(scoreText.text);
    }
}
