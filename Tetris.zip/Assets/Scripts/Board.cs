using System.Linq;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.Tilemaps;

public class Board : MonoBehaviour
{
    public Tilemap tilemap { get; private set; }
    public TileBase tileBase;
    public Piece activePiece { get; private set; }
    public Piece n_piece { get; private set; }
    //public Piece h_piece { get; private set; }


    public TetrominoData[] tetrominoes;
    
    public Vector2Int boardSize = new Vector2Int(10, 20);
    public Vector3Int spawnPosition = new Vector3Int(-1, 8, 0);
    private Score _score;
    private bool[] bag_7 = new bool[7] {true, true, true, true, true, true, true };
    public int currblock;
    public int nextblock;

    public TetrominoData persistant_Data; //����

    public int holdblock = -1;
    public RectInt Bounds {
        get
        {
            Vector2Int position = new Vector2Int(-boardSize.x / 2, -boardSize.y / 2);
            return new RectInt(position, boardSize);
        }
    }

    private void Awake()
    {
        _score = FindObjectOfType<Score>();
        tilemap = GetComponentInChildren<Tilemap>();
        activePiece = GetComponentInChildren<Piece>();
        //h_piece = new Piece();
 
        n_piece = new Piece();

        for (int i = 0; i < tetrominoes.Length; i++) {
            tetrominoes[i].Initialize();
        }
    }

    private void Start()
    {
        int random = Random.Range(0, tetrominoes.Length);
        nextblock = random;
        currblock = nextblock;
        bag_7[random] = false;
        
        SpawnPiece();
        //Hold();
    }

    /*public void Hold()
    {
        //defalut value -- BETA -- MUST DELETE AFTER

        if(holdblock == -1)
        {
            holdblock = currblock;
            SpawnPiece();
            Hold_Block(currblock);
        }
        else
        {
            TetrominoData data = tetrominoes[holdblock];
            holdblock = currblock;

            activePiece.Initialize(this, spawnPosition, data);

            Holdblock_Clear(currblock);
            Hold_Block(currblock);

            if (IsValidPosition(activePiece, spawnPosition))
            {
                Set(activePiece);
            }
            else
            {
                GameOver();
            }
        }
    }*/

    public void SpawnPiece()
    {
        int random = 0;

        //checking tetrimino bag_7(bool)'s state, and reset to true if all is false
        for (int i = 0; i < bag_7.Length; i++)
        {
            if (bag_7[i] == true) break;
            if (i == bag_7.Length - 1)
            {
                for (int j = 0; j < bag_7.Length; j++)
                {
                    bag_7[j] = true;
                }
            }
        }
        while (true)
        {
            random = Random.Range(0, tetrominoes.Length);
            if (bag_7[random])
            {
                bag_7[random] = false;
                break;
            }
        }
        
        TetrominoData data = tetrominoes[nextblock]; //set tetrimino data to nextblock that previously called
        activePiece.Initialize(this, spawnPosition, data);


        //currblock = nextblock;

        //set nextblock's data
        nextblock = random;
        Nextblock_Clear(nextblock);
        Next_Block(nextblock);
        
        if (IsValidPosition(activePiece, spawnPosition)) {
            Set(activePiece);
        } else {
            GameOver();
        }
    }

    /*private void Hold_Block(int hold_block)
    {
        TetrominoData data = tetrominoes[nextblock];
        h_piece.Initialize(this, spawnPosition, data);
        for (int i = 0; i < h_piece.cells.Length; i++)
        {
            Vector3Int offset = new Vector3Int(-10, 7, 0);
            Vector3Int tilePosition = h_piece.cells[i] + offset;
            tilemap.SetTile(tilePosition, h_piece.data.tile);
        }
    }

    public void Holdblock_Clear(int hold_block)
    {
        tilemap.SetTile(new Vector3Int(-9, 7, 0), null);
        tilemap.SetTile(new Vector3Int(-10, 7, 0), null);
        tilemap.SetTile(new Vector3Int(-11, 7, 0), null);
        tilemap.SetTile(new Vector3Int(-12, 7, 0), null);
        tilemap.SetTile(new Vector3Int(-9, 8, 0), null);
        tilemap.SetTile(new Vector3Int(-10, 8, 0), null);
        tilemap.SetTile(new Vector3Int(-11, 8, 0), null);
        tilemap.SetTile(new Vector3Int(-12, 8, 0), null);

    }*/

    private void Next_Block(int next_block)
    {
        TetrominoData data = tetrominoes[nextblock];
        n_piece.Initialize(this, spawnPosition, data);
        for (int i = 0; i < n_piece.cells.Length; i++)
        {
            Vector3Int offset = new Vector3Int(9, 5, 0);
            Vector3Int tilePosition = n_piece.cells[i] + offset;
            tilemap.SetTile(tilePosition, n_piece.data.tile);
        }
    }

    public void Nextblock_Clear(int next_block)
    {
        tilemap.SetTile(new Vector3Int(8, 5, 0), tileBase);
        tilemap.SetTile(new Vector3Int(9, 5, 0), tileBase);
        tilemap.SetTile(new Vector3Int(10, 5, 0), tileBase);
        tilemap.SetTile(new Vector3Int(11, 5, 0), tileBase);
        tilemap.SetTile(new Vector3Int(8, 6, 0), tileBase);
        tilemap.SetTile(new Vector3Int(9, 6, 0), tileBase);
        tilemap.SetTile(new Vector3Int(10, 6, 0), tileBase);
        tilemap.SetTile(new Vector3Int(11, 6, 0), tileBase);

    }

    public void GameOver()
    {
        tilemap.ClearAllTiles();

        // Do anything else you want on game over here..
    }

    public void Set(Piece piece)
    {
        for (int i = 0; i < piece.cells.Length; i++)
        {
            Vector3Int tilePosition = piece.cells[i] + piece.position;
            tilemap.SetTile(tilePosition, piece.data.tile);
        }
    }

    public void Clear(Piece piece)
    {
        for (int i = 0; i < piece.cells.Length; i++)
        {
            Vector3Int tilePosition = piece.cells[i] + piece.position;
            tilemap.SetTile(tilePosition, null);
        }
    }

    public bool IsValidPosition(Piece piece, Vector3Int position)
    {
        RectInt bounds = Bounds;

        // The position is only valid if every cell is valid
        for (int i = 0; i < piece.cells.Length; i++)
        {
            Vector3Int tilePosition = piece.cells[i] + position;

            // An out of bounds tile is invalid
            if (!bounds.Contains((Vector2Int)tilePosition)) {
                return false;
            }

            // A tile already occupies the position, thus invalid
            if (tilemap.HasTile(tilePosition)) {
                return false;
            }
        }

        return true;
    }

    public void ClearLines()
    {
        RectInt bounds = Bounds;
        int row = bounds.yMin;

        // Clear from bottom to top
        while (row < bounds.yMax)
        {
            // Only advance to the next row if the current is not cleared
            // because the tiles above will fall down when a row is cleared
            if (IsLineFull(row)) {
                LineClear(row);
                _score.IncreaseScore(500);
            } else {
                row++;
            }
        }
    }

    public bool IsLineFull(int row)
    {
        RectInt bounds = Bounds;

        for (int col = bounds.xMin; col < bounds.xMax; col++)
        {
            Vector3Int position = new Vector3Int(col, row, 0);

            // The line is not full if a tile is missing
            if (!tilemap.HasTile(position)) {  
                return false;
            }
        }

        return true;
    }

    public void LineClear(int row)
    {
        RectInt bounds = Bounds;

        // Clear all tiles in the row
        for (int col = bounds.xMin; col < bounds.xMax; col++)
        {
            Vector3Int position = new Vector3Int(col, row, 0);
            tilemap.SetTile(position, null);
        }

        // Shift every row above down one
        while (row < bounds.yMax)
        {
            for (int col = bounds.xMin; col < bounds.xMax; col++)
            {
                Vector3Int position = new Vector3Int(col, row + 1, 0);
                TileBase above = tilemap.GetTile(position);

                position = new Vector3Int(col, row, 0);
                tilemap.SetTile(position, above);
            }

            row++;
        }
    }

}